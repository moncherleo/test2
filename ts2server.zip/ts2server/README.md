# TS2 TN3270 Server

A standalone Java TN3270 server that simulates TSYS TS2 credit card account inquiry screens for testing with IBM 3270 terminal emulators such as Hummingbird HostExplorer.

## Screens

| Transaction | Description |
|-------------|-------------|
| **OTIS** | Login screen with TSYS logo, operator ID, password, and transaction/key fields |
| **IAGI** | Inquire Account General Information — balances, payment info, delinquency buckets, account status flags |
| **IAED** | Inquire Account Event Detail — scrollable event log with date/time/type/operator per event |

## Prerequisites

- Java 11 or higher
- Maven 3.6 or higher (for building from source)

## Build

```
mvn package
```

The JAR is written to `target/ts2server.jar`.

## Run

```
java -jar target/ts2server.jar [port]
```

Default port is **3900**. Example with a custom port:

```
java -jar target/ts2server.jar 5000
```

## Connect with Hummingbird HostExplorer

1. Create a new TN3270 session
2. Set **Host** to `localhost`
3. Set **Port** to `3900` (or your custom port)
4. Set **Terminal type** to `IBM-3279-2-A`
5. Connect — the OTIS login screen appears immediately

## Login

The server accepts any non-blank Operator ID. Password is not validated.

- Leave **TRANS** blank (or type `IAGI`) to go to the Account General Information screen
- Type `IAED` in the **TRANS** field to go directly to the Event Detail screen
- Enter a 13-digit account key in the **KEY** field

## Sample Account Keys

| Key | Name | Limit | Balance |
|-----|------|-------|---------|
| `4538160103003` | MR CIPAPERLESS LOCINTRA50 | $10,000 | ($5.77) credit |
| `4538232796941` | MR MOHA ELIA | $99,000 | $10,023.85 |
| `4538160006065` | MRS LESLIE HEINRICHS | $400,000 | $1,975.01 |

## Key Bindings

| Screen | Key | Action |
|--------|-----|--------|
| OTIS | Enter | Login and navigate to IAGI or IAED |
| OTIS | F3 / Clear | Refresh login screen |
| IAGI | Enter | Re-inquire account (change key to look up another account) |
| IAGI | F5 | Go to IAED (event detail) |
| IAGI | F3 | Return to OTIS login |
| IAGI | Clear | Refresh current account |
| IAED | F7 | Page backward |
| IAED | F8 | Page forward |
| IAED | F3 / F4 | Return to IAGI |
| IAED | Clear | Refresh current page |

## Project Structure

```
ts2server/
├── pom.xml
└── src/main/java/com/ts2server/
    ├── Ts2Server.java          # Main entry point — TCP listener, spawns one thread per client
    ├── ClientSession.java      # TN3270 negotiation + OTIS/IAGI/IAED state machine
    ├── DataStreamBuilder.java  # Fluent builder for IBM 3270 data streams (EBCDIC, SBA, SF, SFE)
    ├── Tn3270.java             # TN3270/Telnet constants, buffer address encoding/decoding
    ├── data/
    │   ├── Account.java        # Account data model (all IAGI fields)
    │   ├── AccountEvent.java   # Event record model (IAED entries)
    │   └── SampleData.java     # Three hardcoded sample accounts
    └── screens/
        ├── OtisScreen.java     # OTIS login screen builder
        ├── IagiScreen.java     # IAGI account general info screen builder
        └── IaedScreen.java     # IAED account event detail screen builder (paginated)
```
